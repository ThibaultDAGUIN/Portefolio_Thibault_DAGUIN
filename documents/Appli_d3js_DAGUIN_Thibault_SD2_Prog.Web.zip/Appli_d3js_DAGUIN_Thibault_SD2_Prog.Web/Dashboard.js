// -----------------------------------------------------------------------------------
// ------------------------------------  Header  ------------------------------------
// -----------------------------------------------------------------------------------


// Créer le bandeau header
const header = d3.select("body")
  .append("div")
  .attr("class", "header")
  .text("Application D3JS - Logements AirBnB à Paris - Thibault DAGUIN - BUT SD 2eme Année - Programmation web (F. Garnier)");

  header.style("background-color", "#3C8DBC")
  .style("color", "white")
  .style("position", "sticky")
  .style("top", "0")
  .style("text-align", "center")
  .style("width", "100%")
  .style("padding", "10px");



// -----------------------------------------------------------------------------------
// ------------------------------------  DONNEES  ------------------------------------
// -----------------------------------------------------------------------------------


// Chargement des données depuis l'URL spécifiée
d3.csv("http://data.insideairbnb.com/france/ile-de-france/paris/2023-12-12/visualisations/listings.csv")
    .then(data => {
        // Typage des données et calcul des données supplémentaires
        const processedData = data.map(d => {
            const nameComponents = d.name.split(' · ');
            const type = nameComponents[0];
            let rating = 0;
            let bedrooms = 0;
            let beds = 0;
            let baths = 0;

            nameComponents.forEach(component => {
                if (component.includes('★')) {
                    rating = parseFloat(component.replace('★', ''));
                } else if (component.includes('bedroom')) {
                    bedrooms = parseInt(component);
                } else if (component.includes('bed')) {
                    beds = parseInt(component);
                } else if (component.includes('bath')) {
                    baths = parseFloat(component);
                }
            });
            
            if (isNaN(rating)) {
                rating = '-'; 
            }
            // Parse le prix en entier s'il est défini, sinon laisser vide (pour éviter NaN)
            const price = d.price ? parseInt(d.price) : '-';

            return {
                id: parseInt(d.id),
                name: String(d.name),
                host_id: parseInt(d.host_id),
                host_name: String(d.host_name),
                neighbourhood: String(d.neighbourhood),
                latitude: parseFloat(d.latitude),
                longitude: parseFloat(d.longitude),
                room_type: String(d.room_type),
                price: price,
                minimum_nights: parseInt(d.minimum_nights),
                number_of_reviews: parseInt(d.number_of_reviews),
                last_review: new Date(d.last_review),
                reviews_per_month: parseFloat(d.reviews_per_month),
                calculated_host_listings_count: parseInt(d.calculated_host_listings_count),
                availability_365: parseInt(d.availability_365),
                number_of_reviews_ltm: parseInt(d.number_of_reviews_ltm),
                'Type de logement': type.includes('in Paris') ? type.replace(' in Paris', '') : type,
                'Note': rating,
                'Chambres': bedrooms,
                'Lits': beds,
                'sdb': baths
            };
        });

// -----------------------------------------------------------------------------------
// -----------------------------------  Graphs TD  -----------------------------------
// -----------------------------------------------------------------------------------


        // Sélectionner le body du document
        const body = d3.select("body");

        // Ajouter le titre centré au body
        body.append("h2")
            .text("Graphiques du TD")
            .style("text-align", "center")
            .style("border","2px solid black")
            .style("padding","10px");
           

        // initialiser données
        const donnees = [
            { type: "Entire home/apt", count: 0, price: 0 },
            { type: "Private room", count: 0, price: 0 },
            { type: "Shared room", count: 0, price: 0 },
            { type: "Other type", count: 0, price: 0}
        ];

        var type_modalites = donnees.map(function(d) { return d.type; });
        var prices = donnees.map(function(d) { return d.price; });
        var price_min = d3.min(prices);
        var price_max = d3.max(prices);
        var qt2num = d3.scaleLinear()
            .domain([price_min, price_max])
            .range([0, 100]);
        var qt2col = d3.scaleLinear()
            .domain([price_min, price_max])
            .range(["lightgreen", "steelblue"]);
        var ql2num = d3.scaleBand()
            .domain(type_modalites)
            .range([0, 100]);
        var ql2col = d3.scaleOrdinal(d3["schemeSet1"])
            .domain(type_modalites);
        var tbody = d3.select("#tab").selectAll("tr")
            .data(donnees)
            .enter().append("tr")
            .html(function(d) {
                var chaine = "<td>" + d.type + "</td>" +
                    "<td>" + ql2num(d.type) + "</td>" +
                    "<td style='background-color:" + ql2col(d.type) + "'></td><td></td>" +
                    "<td>" + d.price + "</td>" +
                    "<td>" + qt2num(d.price) + "</td>" +
                    "<td style='background-color:" + qt2col(d.price) + "'></td>";
                return chaine;
            });

        // Création de la division avec l'ID "graph"
        d3.select("body").append("div")
            .attr("id", "graph");

        // Données pour le premier graphique
        const graphData1 = [
            { type: "Entire home/apt", price: d3.mean(processedData.filter(d => d.room_type === "Entire home/apt"), d => d.price) },
            { type: "Private room", price: d3.mean(processedData.filter(d => d.room_type === "Private room"), d => d.price) },
            { type: "Shared room", price: d3.mean(processedData.filter(d => d.room_type === "Shared room"), d => d.price) },
        ];

        // Liste des modalités de la variable type pour le premier graphique
        var typeModalites1 = graphData1.map(function(d) { return d.type; });

        // Définition des marges et de la taille du premier graphique
        var marges1 = {haut: 20, droit: 20, bas: 30, gauche: 40},
            largeurTotale1 = 400,
            hauteurTotale1 = 300,
            largeurInterne1 = largeurTotale1 - marges1.gauche - marges1.droit,
            hauteurInterne1 = hauteurTotale1 - marges1.haut - marges1.bas;

        // Echelle pour les prix sur l'axe Y du premier graphique
        var echelleY1 = d3.scaleLinear()
            .domain([0, d3.max(graphData1, function(d) { return d.price; })])
            .range([hauteurInterne1, 0]);

        // Echelle pour le type sur l'axe X du premier graphique
        var echelleX1 = d3.scaleBand()
            .domain(typeModalites1)
            .range([0, largeurInterne1])
            .padding(0.2);

        // Echelle pour le type affectant une couleur automatique à chaque type du premier graphique
        var echelleCouleur1 = d3.scaleOrdinal(d3["schemeSet1"])
            .domain(typeModalites1);

        // Création de l'axe X du premier graphique
        var axeX1 = d3.axisBottom()
            .scale(echelleX1);

        // Création de l'axe Y du premier graphique
        var axeY1 = d3.axisLeft()
            .scale(echelleY1);

        // Création du premier graphique
        var graphique1 = d3.select("#graph").append("svg")
            .attr("width", largeurTotale1)
            .attr("height", hauteurTotale1)
          .append("g")
            .attr("transform", "translate(" + marges1.gauche + "," + marges1.haut + ")");

        // Ajout de l'axe X au premier graphique
        graphique1.append("g")
            .attr("class", "x axis")
            .attr("transform", "translate(0," + hauteurInterne1 + ")")
          .call(axeX1);

        // Ajout de l'axe Y au premier graphique
        graphique1.append("g")
            .attr("class", "y axis")
          .call(axeY1);

        graphique1.append("text")
            .attr("transform", "rotate(-90)")
            .attr("y", 6)
            .attr("dy", ".71em")
            .style("text-anchor", "end")
            .text("Prix moyen");

        // Ajout d'une barre pour chaque type de logement, avec une taille fonction du prix moyen
        graphique1.selectAll(".bar")
          .data(graphData1)
          .enter()
          .append("rect")
          .attr("class", "bar")
          .attr("x", function(d) { return echelleX1(d.type); })
          .attr("width", echelleX1.bandwidth())
          .attr("y", function(d) { return echelleY1(d.price); })
          .attr("height", function(d) { return hauteurInterne1 - echelleY1(d.price); })
          .style("fill", function(d) { return echelleCouleur1(d.type); });

        // Données pour le deuxième graphique
        const graphData2 = [
            { type: "Entire home/apt", price: d3.mean(processedData.filter(d => d.room_type === "Entire home/apt"), d => d.price) },
            { type: "Private room", price: d3.mean(processedData.filter(d => d.room_type === "Private room"), d => d.price) },
            { type: "Shared room", price: d3.mean(processedData.filter(d => d.room_type === "Shared room"), d => d.price) },
            { type: "Other type", price: d3.mean(processedData.filter(d => !["Entire home/apt", "Private room", "Shared room"].includes(d.room_type)), d => d.price) }
        ];

        const minPrice2 = d3.min(graphData2.map(d => d.price));
        const maxPrice2 = d3.max(graphData2.map(d => d.price));

        // Echelles pour les prix numériques et les couleurs pour le deuxième graphique
        const priceScale2 = d3.scaleLinear()
            .domain([minPrice2, maxPrice2])
            .range([0, 100]);

        const colorScale2 = d3.scaleLinear()
            .domain([minPrice2, maxPrice2])
            .range(["lightgreen", "steelblue"]);

        // Création de la division avec l'ID "graph2"
        d3.select("body").append("div")
            .attr("id", "graph2");

        // Sélection du tbody pour ajouter les données du deuxième graphique
        const tbodyGraph2 = d3.select("#graph2").append("table");

        // Ajout des en-têtes du tableau pour le deuxième graphique
        tbodyGraph2.append("tr")
            .html(`
                <th colspan="3">Type</th>
                <th colspan="3">Price</th>
            `);

        tbodyGraph2.append("tr")
            .html(`
                <th colspan="3">(qualitatif)</th>
                <th colspan="3">(quantitatif)</th>
            `);

        tbodyGraph2.append("tr")
            .html(`
                <th>Original</th>
                <th>Numérique</th>
                <th>Couleur</th>
                <th>Original</th>
                <th>Numérique</th>
                <th>Couleur</th>
            `);

        // Ajout des données dans le tableau pour le deuxième graphique
        tbodyGraph2.selectAll("tr.data-row")
            .data(graphData2)
            .enter().append("tr")
            .attr("class", "data-row")
            .html(function(d) {
                const numericValue = priceScale2(d.price);
                const colorValue = colorScale2(d.price);

                const html = `
                    <td>${d.type}</td>
                    <td>${ql2num(d.type)}</td>
                    <td style="background-color:${ql2col(d.type)}"></td>
                    <td>${d.price.toFixed(0)}</td>
                    <td>${numericValue.toFixed(2)}</td>
                    <td style="background-color:${colorValue}"></td>
                `;
                return html;
            });


// -----------------------------------------------------------------------------------
// -------------------------------  Graphs Statiques  --------------------------------
// -----------------------------------------------------------------------------------

        // Ajouter le titre centré au body
        body.append("h2")
            .text("Graphiques complémentaires")
            .style("text-align", "center")
            .style("border","2px solid black")
            .style("padding","10px");


        body.append("h3")
            .text("Le profil type du logement référencé sur AirBnB (Paris) est un logement muni d'une chambre, d'un lit, d'une salle de bain et bien noté (supérieur à 4/5) ")
            .style("text-align", "center")
            .style("color","#3C8DBF");


// fonction PieChart que je pourrais appeler facilement par la suite 

    function createPieChart(data, containerId, title) {
        const width = 400;
        const height = 400;
        const radius = Math.min(width, height) / 3;
    
        const color = d3.scaleOrdinal(d3.schemeCategory10);
    
        const arc = d3.arc()
            .outerRadius(radius - 10)
            .innerRadius(0);
    
        const pie = d3.pie()
            .sort(null)
            .value(d => d[1]);
    
        const svg = d3.select(containerId).append("svg")
            .attr("width", width)
            .attr("height", height)
            .append("g")
            .attr("transform", "translate(" + width / 2 + "," + height / 2 + ")");
    
        const g = svg.selectAll(".arc")
            .data(pie(data))
            .enter().append("g")
            .attr("class", "arc");
    
        // Ajout des arcs avec transition
        g.append("path")
            .attr("d", arc)
            .style("fill", d => color(d.data[0]))
            .style("opacity", 0) // Opacité initiale à 0
            .transition() // Animation de transition
            .duration(1000) // Durée de l'animation en millisecondes
            .style("opacity", 1); // Opacité finale à 1
        
        // Définition de l'arc agrandi au survol
        const enlargedArc = d3.arc()
            .outerRadius(radius + 10) 
            .innerRadius(0);

        // Sélectionner tous les arcs et leur ajouter un événement de souris
        g.selectAll("path")
            .on("mouseover", function(d) { // Au survol de la souris
                d3.select(this) // Sélectionner l'arc survolé
                    .transition() // Début de l'animation de transition
                    .duration(200) // Durée de l'animation en millisecondes
                    .attr("d", enlargedArc); // Utiliser l'arc agrandi
            })
            .on("mouseout", function(d) { // Lorsque la souris quitte l'arc
                d3.select(this) // Sélectionner l'arc
                    .transition() // Début de l'animation de transition
                    .duration(200) // Durée de l'animation en millisecondes
                    .attr("d", arc); // Revenir à l'arc normal
            });
    
        svg.append("text")
            .attr("x", 0)
            .attr("y", -height / 2 + 20)
            .attr("text-anchor", "middle")
            .style("font-size", "24px")
            .text(title);
    
        const legend = svg.selectAll(".legend")
            .data(data)
            .enter().append("g")
            .attr("class", "legend")
            .attr("transform", (d, i) => "translate(0," + i * 20 + ")");
    
        legend.append("rect")
            .attr("x", width / 2 - 18)
            .attr("width", 18)
            .attr("height", 18)
            .style("fill", d => color(d[0]));
    
        legend.append("text")
            .attr("x", width / 2 - 24)
            .attr("y", 9)
            .attr("dy", ".35em")
            .style("text-anchor", "end")
            .text(d => d[0]);
    
        const tooltip = d3.select("body").append("div")
            .attr("class", "tooltip")
            .style("opacity", 0);
    }
    
// Création d'un conteneur pour les graphiques 3 et 4
const graphContainer1 = d3.select("body").append("div")
    .attr("class", "graph-container");

// Création du graphique 3 dans le conteneur
const graph3Div = graphContainer1.append("div")
    .attr("id", "graph3");

// Création du graphique 4 dans le conteneur
const graph4Div = graphContainer1.append("div")
    .attr("id", "graph4");

// Données pour le graphique 3 (notes par logement)
const notes = [
    ["5", processedData.filter(d => d['Note'] === 5).length],
    ["4+", processedData.filter(d => d['Note'] >= 4 && d['Note'] < 5).length],
    ["3+", processedData.filter(d => d['Note'] >= 3 && d['Note'] < 4).length],
    ["2+", processedData.filter(d => d['Note'] >= 2 && d['Note'] < 3).length],
    ["1+", processedData.filter(d => d['Note'] >= 1 && d['Note'] < 2).length]
];

// Titre du graphique
const graphNotes = "Note des logements AirBnB à Paris";

// Appel de la fonction pour créer le pie chart du graphique 3
createPieChart(notes, "#graph3", graphNotes);

// Données pour le graphique 4 (nombre de chambres par logement)
const bedroomsData = [
    ["0", processedData.filter(d => d['Chambres'] === 0).length],
    ["1", processedData.filter(d => d['Chambres'] === 1).length],
    ["2", processedData.filter(d => d['Chambres'] === 2).length],
    ["3", processedData.filter(d => d['Chambres'] === 3).length],
    ["4", processedData.filter(d => d['Chambres'] === 4).length],
    ["5+", processedData.filter(d => d['Chambres'] >= 5).length]
];

// Titre du graphique 4
const graphTitle4 = "Nombre de chambres par logement";

// Appel de la fonction pour créer le pie chart du graphique 4
createPieChart(bedroomsData, "#graph4", graphTitle4);


// Création d'un conteneur pour les graphiques 5 et 6
const graphContainer2 = d3.select("body").append("div")
    .attr("class", "graph-container");

// Création du graphique 5 dans le conteneur
const graph5Div = graphContainer2.append("div")
    .attr("id", "graph5");

// Création du graphique 6 dans le conteneur
const graph6Div = graphContainer2.append("div")
    .attr("id", "graph6");

// Données pour le graphique 5 (nombre de lits par logement)
const bedsData = [
    ["1", processedData.filter(d => d['Lits'] === 1).length],
    ["2", processedData.filter(d => d['Lits'] === 2).length],
    ["3", processedData.filter(d => d['Lits'] === 3).length],
    ["4", processedData.filter(d => d['Lits'] === 4).length],
    ["5+", processedData.filter(d => d['Lits'] >= 5).length]
];

// Titre du graphique 5
const graphTitle5 = "Nombre de lits par logement";

// Appel de la fonction pour créer le pie chart du graphique 5
createPieChart(bedsData, "#graph5", graphTitle5);


// Données pour le graphique 6 (nombre de sdb par logement)
const sdbData = [
    ["0", processedData.filter(d => d['sdb'] === 0).length],
    ["1", processedData.filter(d => d['sdb'] === 1).length],
    ["2", processedData.filter(d => d['sdb'] === 2).length],
    ["3+", processedData.filter(d => d['sdb'] >= 3).length]
];

// Titre du graphique 6
const graphTitle6 = "Nombre de salles de bain par logement";

// Appel de la fonction pour créer le pie chart du graphique 6
createPieChart(sdbData, "#graph6", graphTitle6);



// -----------------------------------------------------------------------------------
// -------------------------------  Tableur Dynamique  --------------------------------
// -----------------------------------------------------------------------------------



// Ajouter le titre centré au body
d3.select("body").append("h2")
    .text("Tableur dynamique")
    .style("text-align", "center")
    .style("border", "2px solid black")
    .style("padding", "10px");

// Ajouter une remarque concernant la recherche d'intervalle de prix
d3.select("body").append("h5")
    .text("PS : De temps en temps la recherche de prix met du temps mais elle fonctionne :-)")
    .style("text-align", "center");

// Fonction pour obtenir la plage de note correspondante
function getNoteRange(note) {
    switch (note) {
        case '5':
            return ['5', '5'];
        case '4+':
            return ['4', '4.99'];
        case '3+':
            return ['3', '3.99'];
        case '2+':
            return ['2', '2.99'];
        case '1+':
            return ['1', '1.99'];
        default:
            return []; // Retourne une plage vide pour toutes les notes
    }
}

// Fonction pour obtenir la plage de nombre de chambres correspondante
function getBedroomsRange(bedrooms) {
    switch (bedrooms) {
        case '0':
            return [0, 0];
        case '1':
            return [1, 1];
        case '2':
            return [2, 2];
        case '3':
            return [3, 3];
        case '4':
            return [4, 4];
        case '5':
            return [5, 5];
        case '6+':
            return [6, Infinity]; // Pour 6 et plus
        default:
            return []; // Retourne une plage vide pour toutes les valeurs
    }
}

// Sélection de l'élément contenant le tableau et les filtres
const container = d3.select("body").append("div")
    .attr("class", "tableau");

// Création de la section de filtres
const filtersSection = container.append("div")
    .attr("class", "filters-section");

// Création de la section de recherche
const searchSection = container.append("div")
    .attr("class", "search-section");

// Création du conteneur de tableau
const tableContainer = searchSection.append("div")
    .attr("class", "table-container");

// Création du tableau
const table = tableContainer.append("div")
    .attr("class", "table");

// En-têtes de colonnes
const columns = ["Nom de l'hôte", "Quartier", "Prix de la nuit", "Type de logement", "Note", "Chambres", "Lits", "SdB"];

// Ajout de l'en-tête du tableau
const header = table.append("div")
    .attr("class", "row header-row");

header.selectAll("div")
    .data(columns)
    .enter()
    .append("div")
    .attr("class", "cell")
    .text(d => d);

// Ajout des lignes de données au tableau (en filtrant les 20 premières lignes)
const rows = table.selectAll(".row.data-row")
    .data(processedData.slice(0, 20)) // Filtrer les 20 premières lignes
    .enter()
    .append("div")
    .attr("class", "row data-row");

// Ajout des cellules de données aux lignes
rows.selectAll(".cell")
    .data(d => [
        d.host_name,
        d.neighbourhood,
        d.price,
        d['Type de logement'],
        d['Note'],
        d['Chambres'],
        d['Lits'],
        d['sdb']
    ])
    .enter()
    .append("div")
    .attr("class", "cell")
    .text(d => d);

// Créer les filtres
const filters = filtersSection.append("div")
    .attr("class", "filters");

// Créer les filtres pour les notes
const ratingsFilter = filters.append("select")
    .attr("id", "ratings")
    .on("change", filterData);

ratingsFilter.append("option")
    .attr("value", "Toutes les notes")
    .text("Toutes les notes");

const ratingsOptions = ["5", "4+", "3+", "2+", "1+"];

ratingsFilter.selectAll("option")
    .data(ratingsOptions)
    .enter()
    .append("option")
    .attr("value", d => d)
    .text(d => d);

// Filtre par prix min
const minPriceFilter = filters.append("input")
    .attr("id", "minPrice")
    .attr("type", "number")
    .attr("placeholder", "Prix min.")
    .on("input", filterData);

// Filtre par prix max
const maxPriceFilter = filters.append("input")
    .attr("id", "maxPrice")
    .attr("type", "number")
    .attr("placeholder", "Prix max.")
    .on("input", filterData);

// Filtre par quartier
const neighbourhoods = [...new Set(processedData.map(d => d.neighbourhood))];
const neighbourhoodFilter = filters.append("select")
    .attr("id", "neighbourhood")
    .on("change", filterData);

neighbourhoodFilter.append("option")
    .attr("value", "") // Valeur par défaut
    .text("Tous les quartiers");

neighbourhoodFilter.selectAll("option.neighbourhood")
    .data(neighbourhoods)
    .enter()
    .append("option")
    .attr("class", "neighbourhood")
    .attr("value", d => d)
    .text(d => d);

// Filtre par nombre de chambres
const bedroomsOptions = ["Tous les nombres de chambres", "0", "1", "2", "3", "4", "5", "6+"];

const bedroomsFilter = filters.append("select")
    .attr("id", "bedrooms")
    .on("change", filterData);

bedroomsFilter.selectAll("option")
    .data(bedroomsOptions)
    .enter()
    .append("option")
    .attr("value", d => d)
    .text(d => d);

// Fonction pour filtrer les données en fonction des filtres sélectionnés
function filterData() {
    // Récupérer les valeurs des filtres
    const selectedRatings = document.getElementById('ratings').value;
    const minPrice = document.getElementById('minPrice').value;
    const maxPrice = document.getElementById('maxPrice').value;
    const selectedNeighbourhood = document.getElementById('neighbourhood').value;
    const selectedBedrooms = document.getElementById('bedrooms').value;

    // Filtrer les données en fonction des valeurs sélectionnées
    const filteredData = processedData.filter(d => {
        // Filtrer par note
        if (selectedRatings !== '' && selectedRatings !== 'Toutes les notes') {
            const [minNote, maxNote] = getNoteRange(selectedRatings);
            if (parseFloat(d['Note']) < parseFloat(minNote) || parseFloat(d['Note']) > parseFloat(maxNote) || d['Note'] === '-') {
                return false;
            }
        }

        // Filtrer par prix
        if (minPrice !== '' && (parseInt(d.price) < parseInt(minPrice) || d.price === '-')) {
            return false;
        }
        if (maxPrice !== '' && (parseInt(d.price) > parseInt(maxPrice) || d.price === '-')) {
            return false;
        }

        // Filtrer par quartier
        if (selectedNeighbourhood !== '' && d.neighbourhood !== selectedNeighbourhood) {
            return false;
        }

        // Filtrer par nombre de chambres
        if (selectedBedrooms !== '' && selectedBedrooms !== 'Tous les nombres de chambres') {
            const [minBedrooms, maxBedrooms] = getBedroomsRange(selectedBedrooms);
            const numBedrooms = parseInt(d['Chambres']);
            if (numBedrooms < minBedrooms || numBedrooms > maxBedrooms) {
                return false;
            }
        }

        // Retourner true si aucune des conditions de filtrage n'est satisfaite
        return true;
    });

    // Mettre à jour le tableau avec les données filtrées
    updateTable(filteredData);
}

// Fonction pour mettre à jour le tableau en fonction des données filtrées
function updateTable(data) {
    // Supprimer les lignes existantes
    table.selectAll(".data-row").remove();

    // Ajouter les nouvelles lignes de données
    const rows = table.selectAll(".row.data-row")
        .data(data)
        .enter()
        .append("div")
        .attr("class", "row data-row");

    // Ajouter les cellules de données aux lignes
    rows.selectAll(".cell")
        .data(d => [
            d.host_name,
            d.neighbourhood,
            d.price,
            d['Type de logement'],
            d['Note'],
            d['Chambres'],
            d['Lits'],
            d['sdb']
        ])
        .enter()
        .append("div")
        .attr("class", "cell")
        .text(d => d);
}


    })
    .catch(error => {
        console.error('Erreur lors du chargement des données :', error);
    });

